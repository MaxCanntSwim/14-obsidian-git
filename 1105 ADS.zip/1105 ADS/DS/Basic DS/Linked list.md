Linked lists are [[Data Structures]] where items in the data structure point to other items in the data structure. There usualy is no direct access to the information in the data structure and it is navigated by using next or preveous reference.

Tags: #dataStructure